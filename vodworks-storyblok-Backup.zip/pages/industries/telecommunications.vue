<template>
  <div v-if="!pageData">
    <div class="text-center py-20">
      <h2 class="text-2xl font-bold">Oops! Page not found</h2>
      <p class="mt-8">The requested content is not available.</p>
    </div>
  </div>

  <div v-else>
    <!-------------------------------- Hero --------------------------------------------------------------->
    <IndustriesHeroSection :data="industryHeroSection" />
    <!---------------------------------------------------------------------------------------------------->

    <!------------------- Industry Solutions ----------------------------------------->
    <IndustriesSolutionCardsSection :data="{
      industrySolutionSection,
      gridlayout: 'three-cols'
    }" />
    <!---------------------------------------------------------------------------------------------------->

    <!------------------------------- Our Success Stories------------------------------------------------->
    <CaseStudiesSection :data="{
      title: 'Our Case Studies',
      animated_word: '',
      description: '',
      getCasesData,
      isDarkMode: true,
    }" />
    <!--------------------------------------------------------------------------------------------------->

    <!----------------------------------------- Blog --------------------------------------------------->
    <ArticlesSections :data="{
      title: 'Our Latest Blog ',
      animated_word: 'Posts',
      getBlogData,
      isDarkMode: false
    }" />
    <!------------------------------------------------------------------------------------------------>

    <!----------------------------- What Our Clients Say --------------------------------------------->
    <WhatOurClientsSay :data="{
      title: 'What Our Clients',
      animated_word: 'Say',
      getTestimonialsData,
      isDarkMode: true
    }" />
    <!---------------------------------------------------------------------------------------------->

    <!--------------------------------------------------------------------------------------------->
    <AboutVodworks :data="{
      isDarkMode: false
    }" />
    <!--------------------------------------------------------------------------------------------->

    <!----------------------------- Get in Touch with us------------------------------------------->
    <GetInTouchWithUs :data="{
      title: 'Get in Touch with us',
      isDarkSectionAtTop: false
    }" />
    <!-------------------------------------------------------------------------------------------->

  </div>
</template>

<script>
export default {
  async asyncData(context) {

    try {
      const path =
        context.route.path === '/'
          ? 'home'
          : context.route.path.replace(/^\/+/, '')

      const [pageDataRes, allCasesRes, allArticlesRes, allTestimonialsRes] = await Promise.all([
        context.app.$storyapi.get(`cdn/stories/${path}`, {
          version: 'published',
          resolve_relations: 'industries-container.industries'
        }),
        context.app.$storyapi.get('cdn/stories/', {
          version: 'published',
          starts_with: 'cases/',
          per_page: 3,
          sort_by: 'first_published_at:desc',
          resolve_relations: 'case-studies-container.case_studies',
        }),
        context.app.$storyapi.get('cdn/stories/', {
          version: 'published',
          starts_with: 'blogs/',
          per_page: 4,
          sort_by: 'first_published_at:desc',
          resolve_relations: 'blog-container.blog',
        }),
        context.app.$storyapi.get('cdn/stories/', {
          version: 'published',
          starts_with: 'testimonials/',
          resolve_relations: 'testimonial-container.testimonials_list',
        })
      ])
      return {
        pageData: pageDataRes.data,
        allCases: allCasesRes.data,
        allArticles: allArticlesRes.data,
        allTestimonials: allTestimonialsRes.data,
      }
    }
    catch (err) {
      // eslint-disable-next-line no-console
      console.error("404 happened on route:", context.route.path)
      // eslint-disable-next-line no-console
      console.error(err.response?.data || err)
      return { pageData: null }
    }
  },

  data() {
    return {
      story: { content: {} },
    }
  },

  head() {
    return {
      title: 'Telecommunication Software Development | Vodworks ',
      meta: [
        {
          hid: 'description',
          name: 'description',
          content: 'Empowering telecom through advanced software solutions. Vodworks drives innovation in telecommunication software development industry.'
        },
        {
          hid: 'keywords',
          name: 'keywords',
          content: 'telecommunication industry, telco industry, telecom software development, telecommunication services industry, innovation in telecommunication industry, telecom software development services, telecom software services, telecom software solutions, telecom application development, telecommunications software solutions, telecoms software development, software telecom'
        },
        {
          hid: 'og:title',
          name: 'og:title',
          property: 'og:title',
          content: 'Telecommunication Software Development | Vodworks ',
        },
        {
          hid: 'og:description',
          name: 'og:description',
          property: 'og:description',
          content: 'Empowering telecom through advanced software solutions. Vodworks drives innovation in telecommunication software development industry.',
        },
      ],
    }
  },

  computed: {
    industryHeroSection() {
      return this.pageData.story.content.body.find(function (obj) {
        return obj.component === 'industries_hero_section';
      })
    },
    industrySolutionSection() {
      return this.pageData.story.content.body.find(function (obj) {
        return obj.component === 'industries_solution_section';
      })
    },
    getCasesData() {
      return this.allCases
    },
    getBlogData() {
      return this.allArticles
    },
    getTestimonialsData() {
      return this.allTestimonials
    },
    // About Vodworks

  }
}
</script>